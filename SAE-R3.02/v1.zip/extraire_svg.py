# Ce programme fonctionne seul, avec un SVG placé à côté de lui.
# Rien à installer : l'outil ci-dessous est fourni avec Python.

import xml.etree.ElementTree as ET

fichier = r"C:\Users\basile\Documents\Cours_IUT\SAE_DROU\TEST\carrefour.svg"

# Lire le fichier SVG
arbre = ET.parse(fichier)

# Récupérer l'élément principal <svg>
racine = arbre.getroot()

print("Le fichier SVG a bien été lu")


# Types d'objets que l'on veut lire
types_a_lire = ["path", "circle", "rect", "g", "text"]

nombre_objets = 0


# Parcourir tous les objets du SVG
for objet in racine.iter():

    # Enlever le début bizarre du nom XML
    # Exemple :
    # {http://www.w3.org/2000/svg}path
    # devient :
    # path
    type_objet = objet.tag.replace(
        "{http://www.w3.org/2000/svg}",
        ""
    )

    # Vérifier si l'objet nous intéresse
    if type_objet in types_a_lire:

        nombre_objets = nombre_objets + 1

        print()
        print("------------------------------")
        print("Objet numéro :", nombre_objets)
        print("Type :", type_objet)

        # Afficher toutes les informations de l'objet
        for nom, valeur in objet.attrib.items():
            print(nom, ":", valeur)

        # Si c'est du texte, afficher le texte
        if type_objet == "text":
            print("Texte affiché :", objet.text)


# Afficher le bilan
print()
print("Lecture terminée.")
print("Nombre d'objets affichés :", nombre_objets)