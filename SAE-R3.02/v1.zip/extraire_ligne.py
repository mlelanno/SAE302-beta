import xml.etree.ElementTree as ET

fichier = r"C:\Users\basile\Documents\Cours_IUT\SAE_DROU\TEST\carrefour.svg"

# Lire le SVG
arbre = ET.parse(fichier)
racine = arbre.getroot()

# Parcourir les objets
for objet in racine.iter():

    # Chercher uniquement l'objet appelé path2
    if objet.get("id") == "path2":

        # Récupérer le texte qui décrit la ligne
        texte = objet.get("d")
        print("Tracé trouvé :", texte)

        # Découper ce texte en plusieurs morceaux
        morceaux = texte.split()
        print("Liste obtenue :", morceaux)

        # Transformer les coordonnées en nombres
        x_debut = float(morceaux[1])
        y_debut = float(morceaux[2])

        x_fin = float(morceaux[4])
        y_fin = float(morceaux[5])

        # Afficher les deux points
        print("Point de départ : x =", x_debut, "y =", y_debut)
        print("Point d'arrivée : x =", x_fin, "y =", y_fin)